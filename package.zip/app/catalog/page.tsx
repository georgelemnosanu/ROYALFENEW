"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Heart, ShoppingCart, Search } from "lucide-react"
import { productService, categoryService, type Product, type Category } from "@/lib/api"

export default function CatalogPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  useEffect(() => {
    filterProducts()
  }, [products, searchTerm, selectedCategory])

  const loadData = async () => {
    try {
      const [productsData, categoriesData] = await Promise.all([productService.getAll(), categoryService.getAll()])
      setProducts(productsData)
      setCategories(categoriesData)
    } catch (error) {
      console.error("Error loading data:", error)
    } finally {
      setLoading(false)
    }
  }

  const filterProducts = () => {
    let filtered = products

    if (searchTerm) {
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.description?.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter((product) => product.categoryId?.toString() === selectedCategory)
    }

    setFilteredProducts(filtered)
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-black/90 backdrop-blur-md border-b border-[#FFD700]/20">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="relative">
                <svg className="w-8 h-8 text-[#FFD700]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M5 16L3 7l5.5 4L12 4l3.5 7L21 7l-2 9H5zm2.7-2h8.6l.9-4.4L14 12l-2-4-2 4-3.2-2.4L7.7 14z" />
                </svg>
                <div className="absolute inset-0 w-8 h-8 bg-[#FFD700]/30 rounded-full blur-lg"></div>
              </div>
              <div className="text-xl font-light tracking-[0.2em] text-[#FFD700]">
                ROYAL ESSENCE
                <span className="block text-xs font-thin tracking-[0.3em] text-[#FFD700]/80">LUXURY</span>
              </div>
            </Link>
            <div className="hidden md:flex items-center space-x-12">
              <Link
                href="/"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                HOME
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                COLLECTION
                <div className="absolute -bottom-1 left-0 w-full h-px bg-[#FFD700]"></div>
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                STORY
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                CONTACT
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/wishlist">
                <Button variant="ghost" size="icon" className="text-[#FFD700] hover:bg-[#FFD700]/10">
                  <Heart className="h-5 w-5" />
                </Button>
              </Link>
              <Link href="/cart">
                <Button
                  variant="outline"
                  className="border-[#FFD700]/50 text-[#FFD700] hover:bg-[#FFD700]/10 hover:border-[#FFD700] rounded-none px-4 py-2 text-xs tracking-[0.2em]"
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  CART (0)
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="pt-32 pb-16 bg-black relative">
        <div className="absolute inset-0 z-0 opacity-20">
          <img
            src="/placeholder.svg?height=1080&width=1920"
            alt="Desert background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center space-y-4 max-w-3xl mx-auto">
            <h1 className="text-5xl font-thin tracking-[0.2em] text-[#FFD700]">THE COLLECTION</h1>
            <div className="inline-block border-t border-[#FFD700]/30 w-24 my-6"></div>
            <p className="text-[#FFD700]/70 tracking-wider">
              Discover our exclusive fragrances, each a masterpiece of Arabian perfumery
            </p>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-black border-b border-[#FFD700]/20">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 flex-1">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#FFD700]/50 h-4 w-4" />
                <Input
                  placeholder="Search perfumes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-transparent border-[#FFD700]/30 text-[#FFD700] placeholder-[#FFD700]/50"
                />
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full sm:w-48 bg-transparent border-[#FFD700]/30 text-[#FFD700]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent className="bg-black border-[#FFD700]/30">
                  <SelectItem value="all" className="text-[#FFD700]">
                    All Categories
                  </SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id?.toString() || ""} className="text-[#FFD700]">
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2 text-[#FFD700]/70">
              <span>{filteredProducts.length} products found</span>
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16 bg-black">
        <div className="container mx-auto px-6">
          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-800 h-80 w-full mb-6"></div>
                  <div className="bg-gray-800 h-6 w-3/4 mb-2"></div>
                  <div className="bg-gray-800 h-4 w-1/2"></div>
                </div>
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-16">
              <div className="space-y-4">
                <div className="text-6xl">🔍</div>
                <h3 className="text-2xl font-semibold text-[#FFD700]">No products found</h3>
                <p className="text-[#FFD700]/70">Try adjusting your search or filters</p>
                <Button
                  onClick={() => {
                    setSearchTerm("")
                    setSelectedCategory("all")
                  }}
                  variant="outline"
                  className="border-[#FFD700]/50 text-[#FFD700] hover:bg-[#FFD700]/10 hover:border-[#FFD700]"
                >
                  Reset filters
                </Button>
              </div>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {filteredProducts.map((product) => (
                <div key={product.id} className="group relative">
                  <div className="relative overflow-hidden">
                    {product.imageUrl ? (
                      <img
                        src={product.imageUrl || "/placeholder.svg"}
                        alt={product.name}
                        crossOrigin="anonymous"
                        className="w-full h-96 object-cover transition-transform duration-700 group-hover:scale-105"
                        onError={(e) => {
                          e.currentTarget.src = "/placeholder.svg?height=400&width=300"
                        }}
                      />
                    ) : (
                      <div className="w-full h-96 bg-gray-800 flex items-center justify-center">
                        <div className="text-[#FFD700]/50 text-center">
                          <div className="text-4xl mb-2">📷</div>
                          <div className="text-sm">No Image</div>
                        </div>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                      <Link href={`/product/${product.id}`}>
                        <span className="text-[#FFD700] border border-[#FFD700]/40 bg-black/30 backdrop-blur-sm px-8 py-3 text-sm tracking-widest block text-center hover:bg-[#FFD700]/10 transition-colors">
                          VIEW DETAILS
                        </span>
                      </Link>
                    </div>
                  </div>
                  <div className="mt-6 text-center">
                    <h3 className="text-xl tracking-widest text-[#FFD700] mb-2">{product.name}</h3>
                    <p className="text-[#FFD700]/70 text-sm mb-2">{product.description}</p>
                    <div className="text-lg font-light text-[#FFD700]">€{product.price}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-black border-t border-[#FFD700]/20">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <Link href="/" className="text-xl font-light tracking-widest text-[#FFD700]">
                ROYAL ESSENCE
              </Link>
            </div>
            <div className="flex space-x-12 mb-6 md:mb-0">
              <Link
                href="/"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                HOME
              </Link>
              <Link href="/catalog" className="text-[#FFD700] transition-colors text-sm tracking-widest">
                COLLECTION
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                STORY
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                CONTACT
              </Link>
            </div>
            <div className="text-[#FFD700]/70 text-sm tracking-wider">© 2024 ROYAL ESSENCE LUXURY</div>
          </div>
        </div>
      </footer>
    </div>
  )
}
