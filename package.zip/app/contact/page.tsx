"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  ArrowLeft,
  Mail,
  Phone,
  MapPin,
  Clock,
  Send,
  Heart,
  ShoppingCart,
  Instagram,
  Facebook,
  Twitter,
} from "lucide-react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setIsSubmitted(true)
        setTimeout(() => {
          setIsSubmitted(false)
          setFormData({
            firstName: "",
            lastName: "",
            email: "",
            phone: "",
            subject: "",
            message: "",
          })
        }, 3000)
      }
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const contactInfo = [
    {
      icon: MapPin,
      title: "VISIT OUR BOUTIQUE",
      details: ["Royal Essence Luxury", "123 Desert Palace Avenue", "Dubai, UAE 12345"],
    },
    {
      icon: Phone,
      title: "CALL US",
      details: ["+971 4 123 4567", "+971 50 123 4567", "Toll Free: 800-ROYAL"],
    },
    {
      icon: Mail,
      title: "EMAIL US",
      details: ["info@royalessence.com", "orders@royalessence.com", "support@royalessence.com"],
    },
    {
      icon: Clock,
      title: "OPENING HOURS",
      details: ["Monday - Friday: 10:00 - 22:00", "Saturday: 10:00 - 23:00", "Sunday: 12:00 - 20:00"],
    },
  ]

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-black/95 backdrop-blur-xl border-b border-[#FFD700]/20 shadow-2xl">
        <div className="container mx-auto px-4 sm:px-6 py-4 sm:py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3 group">
              <div className="relative">
                <svg
                  className="w-6 h-6 sm:w-8 sm:h-8 text-[#FFD700] transition-transform group-hover:scale-110"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M5 16L3 7l5.5 4L12 4l3.5 7L21 7l-2 9H5zm2.7-2h8.6l.9-4.4L14 12l-2-4-2 4-3.2-2.4L7.7 14z" />
                </svg>
                <div className="absolute inset-0 w-6 h-6 sm:w-8 sm:h-8 bg-[#FFD700]/30 rounded-full blur-lg animate-pulse"></div>
              </div>
              <div className="text-base sm:text-xl font-light tracking-[0.2em] text-[#FFD700]">
                ROYAL ESSENCE
                <span className="block text-xs font-thin tracking-[0.3em] text-[#FFD700]/80">LUXURY</span>
              </div>
            </Link>

            <div className="hidden md:flex items-center space-x-8 lg:space-x-12">
              <Link
                href="/"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                HOME
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                COLLECTION
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                STORY
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                CONTACT
                <div className="absolute -bottom-1 left-0 w-full h-px bg-[#FFD700]"></div>
              </Link>
            </div>

            <div className="flex items-center space-x-2 sm:space-x-4">
              <Link href="/wishlist">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-[#FFD700] hover:bg-[#FFD700]/10 rounded-full border border-[#FFD700]/20 hover:border-[#FFD700]/40"
                >
                  <Heart className="h-4 w-4 sm:h-5 sm:w-5" />
                </Button>
              </Link>
              <Link href="/cart">
                <Button
                  variant="outline"
                  className="text-[#FFD700] border-[#FFD700]/60 hover:bg-[#FFD700]/10 hover:border-[#FFD700] rounded-full px-3 sm:px-6 py-2 text-xs sm:text-sm tracking-[0.1em]"
                >
                  <ShoppingCart className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                  <span className="hidden sm:inline">CART</span>
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-24 sm:pt-32 pb-12 sm:pb-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="/placeholder.svg?height=800&width=1920"
            alt="Luxury contact background"
            fill
            className="object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-black/60"></div>
        </div>

        <div className="container mx-auto px-4 sm:px-6 relative z-10">
          <Link
            href="/"
            className="inline-flex items-center text-[#FFD700]/70 hover:text-[#FFD700] mb-6 sm:mb-8 text-sm tracking-widest transition-colors"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            BACK TO HOME
          </Link>

          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-thin tracking-[0.2em] text-[#FFD700] mb-4 sm:mb-6">
              GET IN TOUCH
            </h1>
            <div className="flex justify-center mb-6 sm:mb-8">
              <div className="w-16 sm:w-24 h-px bg-gradient-to-r from-transparent via-[#FFD700] to-transparent"></div>
            </div>
            <p className="text-base sm:text-xl font-light tracking-wider text-[#FFD700]/90 mb-8 sm:mb-12 leading-relaxed max-w-3xl mx-auto">
              Experience the luxury of personalized service. Our fragrance consultants are here to help you discover
              your perfect scent.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Form & Info Section */}
      <section className="py-12 sm:py-20 bg-black relative">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#FFD700]/30 to-transparent"></div>
        <div className="container mx-auto px-4 sm:px-6">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-16">
            {/* Contact Form */}
            <div className="order-2 lg:order-1">
              <Card className="bg-black border-[#FFD700]/20 shadow-2xl">
                <CardHeader className="pb-6">
                  <CardTitle className="text-xl sm:text-2xl font-thin tracking-[0.2em] text-[#FFD700] text-center">
                    SEND US A MESSAGE
                  </CardTitle>
                  <div className="flex justify-center">
                    <div className="w-12 sm:w-16 h-px bg-[#FFD700]/50"></div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4 sm:space-y-6">
                  {isSubmitted ? (
                    <div className="text-center py-8 sm:py-12">
                      <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#FFD700]/20 flex items-center justify-center">
                        <Send className="h-8 w-8 text-[#FFD700]" />
                      </div>
                      <h3 className="text-lg sm:text-xl text-[#FFD700] mb-2 tracking-widest">MESSAGE SENT!</h3>
                      <p className="text-[#FFD700]/70 text-sm sm:text-base">
                        Thank you for contacting us. We'll get back to you within 24 hours.
                      </p>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[#FFD700]/80 mb-2 text-sm tracking-wider">FIRST NAME</label>
                          <Input
                            name="firstName"
                            value={formData.firstName}
                            onChange={handleInputChange}
                            className="bg-transparent border-[#FFD700]/30 text-[#FFD700] placeholder-[#FFD700]/50 focus:border-[#FFD700] h-10 sm:h-12"
                            placeholder="Your first name"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-[#FFD700]/80 mb-2 text-sm tracking-wider">LAST NAME</label>
                          <Input
                            name="lastName"
                            value={formData.lastName}
                            onChange={handleInputChange}
                            className="bg-transparent border-[#FFD700]/30 text-[#FFD700] placeholder-[#FFD700]/50 focus:border-[#FFD700] h-10 sm:h-12"
                            placeholder="Your last name"
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[#FFD700]/80 mb-2 text-sm tracking-wider">EMAIL</label>
                          <Input
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            className="bg-transparent border-[#FFD700]/30 text-[#FFD700] placeholder-[#FFD700]/50 focus:border-[#FFD700] h-10 sm:h-12"
                            placeholder="your@email.com"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-[#FFD700]/80 mb-2 text-sm tracking-wider">PHONE</label>
                          <Input
                            name="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={handleInputChange}
                            className="bg-transparent border-[#FFD700]/30 text-[#FFD700] placeholder-[#FFD700]/50 focus:border-[#FFD700] h-10 sm:h-12"
                            placeholder="+971 50 123 4567"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[#FFD700]/80 mb-2 text-sm tracking-wider">SUBJECT</label>
                        <Input
                          name="subject"
                          value={formData.subject}
                          onChange={handleInputChange}
                          className="bg-transparent border-[#FFD700]/30 text-[#FFD700] placeholder-[#FFD700]/50 focus:border-[#FFD700] h-10 sm:h-12"
                          placeholder="How can we help you?"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-[#FFD700]/80 mb-2 text-sm tracking-wider">MESSAGE</label>
                        <Textarea
                          name="message"
                          value={formData.message}
                          onChange={handleInputChange}
                          className="bg-transparent border-[#FFD700]/30 text-[#FFD700] placeholder-[#FFD700]/50 focus:border-[#FFD700] min-h-[120px] sm:min-h-[150px] resize-none"
                          placeholder="Tell us about your fragrance preferences or any questions you have..."
                          required
                        />
                      </div>

                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-black/60 border-2 border-[#FFD700] text-[#FFD700] hover:bg-[#FFD700] hover:text-black py-3 sm:py-4 text-sm tracking-[0.3em] transition-all duration-300 disabled:opacity-50"
                      >
                        {isSubmitting ? (
                          <div className="flex items-center">
                            <div className="w-4 h-4 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin mr-2"></div>
                            SENDING...
                          </div>
                        ) : (
                          <div className="flex items-center">
                            <Send className="mr-2 h-4 w-4" />
                            SEND MESSAGE
                          </div>
                        )}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Contact Information */}
            <div className="order-1 lg:order-2 space-y-6 sm:space-y-8">
              <div className="text-center lg:text-left">
                <h2 className="text-xl sm:text-2xl font-thin tracking-[0.2em] text-[#FFD700] mb-4">VISIT OUR WORLD</h2>
                <p className="text-[#FFD700]/80 leading-relaxed text-sm sm:text-base">
                  Step into our luxury boutique and immerse yourself in the art of Arabian perfumery. Our expert
                  consultants will guide you through our exclusive collection.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4 sm:gap-6">
                {contactInfo.map((info, index) => (
                  <Card
                    key={index}
                    className="bg-black border-[#FFD700]/20 hover:border-[#FFD700]/40 transition-all duration-300 group"
                  >
                    <CardContent className="p-4 sm:p-6">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#FFD700]/20 flex items-center justify-center group-hover:bg-[#FFD700]/30 transition-colors">
                            <info.icon className="h-5 w-5 sm:h-6 sm:w-6 text-[#FFD700]" />
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-sm sm:text-base font-medium tracking-widest text-[#FFD700] mb-2">
                            {info.title}
                          </h3>
                          <div className="space-y-1">
                            {info.details.map((detail, idx) => (
                              <p key={idx} className="text-xs sm:text-sm text-[#FFD700]/70 break-words">
                                {detail}
                              </p>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Social Media */}
              <Card className="bg-black border-[#FFD700]/20">
                <CardContent className="p-4 sm:p-6">
                  <h3 className="text-base sm:text-lg font-medium tracking-widest text-[#FFD700] mb-4 text-center lg:text-left">
                    FOLLOW US
                  </h3>
                  <div className="flex justify-center lg:justify-start space-x-4">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-[#FFD700] hover:bg-[#FFD700]/10 rounded-full border border-[#FFD700]/20 hover:border-[#FFD700]/40"
                    >
                      <Instagram className="h-4 w-4 sm:h-5 sm:w-5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-[#FFD700] hover:bg-[#FFD700]/10 rounded-full border border-[#FFD700]/20 hover:border-[#FFD700]/40"
                    >
                      <Facebook className="h-4 w-4 sm:h-5 sm:w-5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-[#FFD700] hover:bg-[#FFD700]/10 rounded-full border border-[#FFD700]/20 hover:border-[#FFD700]/40"
                    >
                      <Twitter className="h-4 w-4 sm:h-5 sm:w-5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 sm:py-12 bg-black border-t border-[#FFD700]/20">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
            <div className="text-center md:text-left">
              <Link
                href="/"
                className="text-lg sm:text-xl font-light tracking-widest text-[#FFD700] hover:text-[#FFD700]/90 transition-colors"
              >
                ROYAL ESSENCE
              </Link>
            </div>
            <div className="flex flex-wrap justify-center space-x-6 sm:space-x-12">
              <Link
                href="/"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                HOME
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                COLLECTION
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                STORY
              </Link>
              <Link href="/contact" className="text-[#FFD700] transition-colors text-sm tracking-widest">
                CONTACT
              </Link>
            </div>
            <div className="text-[#FFD700]/70 text-xs sm:text-sm tracking-wider text-center md:text-right">
              © 2024 ROYAL ESSENCE LUXURY
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
