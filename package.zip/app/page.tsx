"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight, Heart, ShoppingCart, Star, Sparkles } from "lucide-react"
import { useSimpleLanguage } from "@/lib/translations"
import { LanguageSelector } from "@/components/language-selector"

interface Product {
  id: number
  name: string
  description: string
  price: number
  imageUrl?: string
}

export default function HomePage() {
  const { t } = useSimpleLanguage()
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadFeaturedProducts()
  }, [])

  const loadFeaturedProducts = async () => {
    try {
      // Simulez încărcarea produselor
      const mockProducts: Product[] = [
        {
          id: 1,
          name: "Desert Rose",
          description: "A luxurious blend of rose and oud",
          price: 299,
          imageUrl: "/placeholder.svg?height=500&width=400",
        },
        {
          id: 2,
          name: "Golden Sands",
          description: "Warm amber and sandalwood notes",
          price: 349,
          imageUrl: "/placeholder.svg?height=500&width=400",
        },
        {
          id: 3,
          name: "Royal Oud",
          description: "Pure oud with jasmine accents",
          price: 499,
          imageUrl: "/placeholder.svg?height=500&width=400",
        },
      ]
      setFeaturedProducts(mockProducts)
    } catch (error) {
      console.error("Error loading products:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-black/95 backdrop-blur-xl border-b border-[#FFD700]/20 shadow-2xl">
        <div className="container mx-auto px-4 sm:px-6 py-4 sm:py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3 group">
              <div className="relative">
                <svg
                  className="w-8 h-8 text-[#FFD700] transition-transform group-hover:scale-110"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M5 16L3 7l5.5 4L12 4l3.5 7L21 7l-2 9H5zm2.7-2h8.6l.9-4.4L14 12l-2-4-2 4-3.2-2.4L7.7 14z" />
                </svg>
                <div className="absolute inset-0 w-8 h-8 bg-[#FFD700]/30 rounded-full blur-lg animate-pulse"></div>
              </div>
              <div className="text-lg sm:text-xl font-light tracking-[0.2em] text-[#FFD700]">
                ROYAL ESSENCE
                <span className="block text-xs font-thin tracking-[0.3em] text-[#FFD700]/80">LUXURY</span>
              </div>
            </Link>

            <div className="hidden md:flex items-center space-x-8 lg:space-x-12">
              <Link
                href="/"
                className="text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                {t.home}
                <div className="absolute -bottom-1 left-0 w-full h-px bg-gradient-to-r from-[#FFD700] to-[#FFD700]/50"></div>
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                {t.collection}
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-gradient-to-r from-[#FFD700] to-[#FFD700]/50 transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                {t.story}
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-gradient-to-r from-[#FFD700] to-[#FFD700]/50 transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                {t.contact}
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-gradient-to-r from-[#FFD700] to-[#FFD700]/50 transition-all duration-300 group-hover:w-full"></div>
              </Link>
            </div>

            <div className="flex items-center space-x-2 sm:space-x-4">
              <LanguageSelector />
              <Link href="/wishlist">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-[#FFD700] hover:bg-[#FFD700]/10 hover:text-[#FFD700] transition-all duration-300 rounded-full border border-[#FFD700]/20 hover:border-[#FFD700]/40 backdrop-blur-sm"
                >
                  <Heart className="h-4 w-4 sm:h-5 sm:w-5" />
                </Button>
              </Link>
              <Link href="/cart">
                <Button
                  variant="outline"
                  className="text-[#FFD700] border-[#FFD700]/60 hover:bg-[#FFD700]/10 hover:border-[#FFD700] rounded-full px-3 sm:px-6 py-2 text-xs sm:text-sm tracking-[0.1em] transition-all duration-300 shadow-lg hover:shadow-[#FFD700]/25 backdrop-blur-sm"
                >
                  <ShoppingCart className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                  <span className="hidden sm:inline">{t.cart}</span> (0)
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/desert-hero.jpg"
            alt="Desert luxury with camel and perfumes"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/50"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-transparent to-black/80"></div>
        </div>

        <div className="container mx-auto px-4 sm:px-6 relative z-10 text-center">
          <div className="flex justify-center mb-6 sm:mb-8">
            <div className="w-24 sm:w-32 h-px bg-gradient-to-r from-transparent via-[#FFD700] to-transparent"></div>
          </div>

          <div className="flex justify-center mb-4 sm:mb-6">
            <div className="relative group">
              <svg
                className="w-12 h-12 sm:w-16 sm:h-16 text-[#FFD700] transition-transform group-hover:scale-110"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M5 16L3 7l5.5 4L12 4l3.5 7L21 7l-2 9H5zm2.7-2h8.6l.9-4.4L14 12l-2-4-2 4-3.2-2.4L7.7 14z" />
              </svg>
              <div className="absolute inset-0 w-12 h-12 sm:w-16 sm:h-16 bg-[#FFD700]/30 rounded-full blur-xl animate-pulse"></div>
              <Sparkles className="absolute -top-2 -right-2 w-4 h-4 text-[#FFD700]/60 animate-pulse" />
            </div>
          </div>

          <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-thin tracking-[0.3em] text-[#FFD700] mb-4 relative">
            <span className="relative inline-block">
              ROYAL
              <div className="absolute -inset-2 bg-[#FFD700]/20 blur-3xl rounded-full"></div>
            </span>
            <span className="block mt-2 relative inline-block">
              ESSENCE
              <div className="absolute -inset-2 bg-[#FFD700]/20 blur-3xl rounded-full"></div>
            </span>
          </h1>

          <div className="flex justify-center items-center my-6 sm:my-8">
            <div className="w-6 sm:w-8 h-px bg-[#FFD700]/70"></div>
            <div className="mx-3 sm:mx-4 w-2 h-2 border border-[#FFD700]/70 rotate-45 animate-pulse"></div>
            <div className="w-6 sm:w-8 h-px bg-[#FFD700]/70"></div>
          </div>

          <p className="text-lg sm:text-xl md:text-2xl font-light tracking-[0.4em] text-[#FFD700] max-w-2xl mx-auto mb-8 sm:mb-12 leading-relaxed">
            {t.luxury_arabian_perfumes}
            <span className="block text-base sm:text-lg mt-2 text-[#FFD700]/80 tracking-[0.2em]">
              {t.crafted_in_desert}
            </span>
          </p>

          <div className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-6 max-w-md sm:max-w-none mx-auto">
            <Button
              asChild
              variant="outline"
              className="bg-black/40 border-2 border-[#FFD700] text-[#FFD700] hover:bg-[#FFD700] hover:text-black font-medium rounded-full px-8 sm:px-12 py-4 sm:py-6 text-sm tracking-[0.3em] transition-all duration-500 hover:shadow-2xl hover:shadow-[#FFD700]/25 relative overflow-hidden group backdrop-blur-sm"
            >
              <Link href="/catalog">
                <span className="relative z-10 flex items-center">
                  {t.discover_collection}
                  <ArrowRight className="ml-3 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </Link>
            </Button>
            <Button
              variant="ghost"
              asChild
              className="text-[#FFD700] hover:text-[#FFD700] border border-[#FFD700]/40 hover:border-[#FFD700] hover:bg-[#FFD700]/10 rounded-full px-8 sm:px-12 py-4 sm:py-6 text-sm tracking-[0.3em] transition-all duration-300 backdrop-blur-sm"
            >
              <Link href="/story">{t.explore_story}</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Collection */}
      <section className="py-16 sm:py-24 bg-gradient-to-b from-black to-gray-900 relative">
        <div className="container mx-auto px-4 sm:px-6 relative z-10">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl font-thin tracking-[0.2em] text-[#FFD700] mb-4">
              {t.signature_collection}
            </h2>
            <div className="flex justify-center">
              <div className="w-16 sm:w-24 h-px bg-gradient-to-r from-transparent via-[#FFD700]/50 to-transparent"></div>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gradient-to-br from-gray-800 to-gray-900 h-80 w-full mb-6 rounded-lg"></div>
                  <div className="bg-gradient-to-r from-gray-800 to-gray-700 h-6 w-3/4 mx-auto rounded"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {featuredProducts.map((product) => (
                <div key={product.id} className="group relative">
                  <div className="relative overflow-hidden rounded-lg bg-gradient-to-br from-gray-900 to-black border border-[#FFD700]/20 hover:border-[#FFD700]/40 transition-all duration-500">
                    <Image
                      src={product.imageUrl || "/placeholder.svg?height=500&width=400"}
                      alt={product.name}
                      width={400}
                      height={500}
                      className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500">
                      <Link href={`/product/${product.id}`}>
                        <Button
                          variant="outline"
                          className="text-[#FFD700] border-[#FFD700]/60 bg-black/60 backdrop-blur-md hover:bg-[#FFD700]/10 hover:border-[#FFD700] rounded-full px-8 py-3 text-sm tracking-widest transition-all duration-300"
                        >
                          {t.view_details}
                        </Button>
                      </Link>
                    </div>
                  </div>

                  <div className="mt-6 text-center">
                    <h3 className="text-lg sm:text-xl tracking-widest text-[#FFD700] mb-2">{product.name}</h3>
                    <p className="text-[#FFD700]/70 text-sm mb-2 line-clamp-2">{product.description}</p>
                    <div className="text-lg font-light text-[#FFD700] flex items-center justify-center">
                      <Star className="h-4 w-4 mr-1 fill-current" />€{product.price}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 sm:py-12 bg-black border-t border-[#FFD700]/20">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
            <div className="text-center md:text-left">
              <Link
                href="/"
                className="text-lg sm:text-xl font-light tracking-widest text-[#FFD700] hover:text-[#FFD700]/90 transition-colors"
              >
                ROYAL ESSENCE
              </Link>
            </div>
            <div className="flex flex-wrap justify-center space-x-6 sm:space-x-12">
              <Link
                href="/"
                className="text-[#FFD700] transition-colors text-sm tracking-widest hover:text-[#FFD700]/80"
              >
                {t.home}
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                {t.collection}
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                {t.story}
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                {t.contact}
              </Link>
            </div>
            <div className="text-[#FFD700]/70 text-xs sm:text-sm tracking-wider text-center md:text-right">
              © 2024 ROYAL ESSENCE LUXURY
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
