"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { use } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Heart, ShoppingCart, Star } from 'lucide-react'

interface Product {
  id: number
  name: string
  description: string
  price: number
}

interface Review {
  id: number
  rating: number
  comment: string
  user?: {
    firstName: string
    lastName: string
  }
  createdAt?: string
}

interface PageProps {
  params: Promise<{ id: string }>
}

export default function ProductPage({ params }: PageProps) {
  // Unwrap params using React.use()
  const { id } = use(params)
  
  const [product, setProduct] = useState<Product | null>(null)
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [newReview, setNewReview] = useState({ rating: 5, comment: "" })
  const [showReviewForm, setShowReviewForm] = useState(false)

  useEffect(() => {
    loadProduct()
  }, [id])

  const loadProduct = async () => {
    try {
      // Use the backend API instead of Next.js API routes
      const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api/v1"
      
      const [productRes, reviewsRes] = await Promise.all([
        fetch(`${API_BASE_URL}/products/${id}`),
        fetch(`${API_BASE_URL}/reviews/product/${id}`),
      ])

      if (productRes.ok) {
        const productData = await productRes.json()
        setProduct(productData)
      }

      if (reviewsRes.ok) {
        const reviewsData = await reviewsRes.json()
        setReviews(reviewsData)
      }
    } catch (error) {
      console.error("Error loading product:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!product?.id || !newReview.comment.trim()) return

    try {
      const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api/v1"
      
      const response = await fetch(`${API_BASE_URL}/reviews`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: product.id,
          rating: newReview.rating,
          comment: newReview.comment,
          userId: 1, // Mock user ID
        }),
      })

      if (response.ok) {
        const review = await response.json()
        setReviews([review, ...reviews])
        setNewReview({ rating: 5, comment: "" })
        setShowReviewForm(false)
      }
    } catch (error) {
      console.error("Error submitting review:", error)
    }
  }

  const renderStars = (rating: number, interactive = false, onRatingChange?: (rating: number) => void) => {
    return (
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type={interactive ? "button" : undefined}
            onClick={interactive && onRatingChange ? () => onRatingChange(star) : undefined}
            className={`${interactive ? "cursor-pointer hover:scale-110" : "cursor-default"} transition-transform`}
          >
            <Star className={`h-4 w-4 ${star <= rating ? "text-[#FFD700] fill-current" : "text-[#FFD700]/30"}`} />
          </button>
        ))}
      </div>
    )
  }

  const averageRating =
    reviews.length > 0 ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length : 0

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-[#FFD700] text-xl tracking-widest">LOADING...</div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl text-[#FFD700] mb-4">PRODUCT NOT FOUND</h1>
          <Link href="/catalog">
            <Button className="bg-[#FFD700] hover:bg-[#FFD700]/90 text-black">RETURN TO COLLECTION</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-black/90 backdrop-blur-md border-b border-[#FFD700]/20">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="relative">
                <svg className="w-8 h-8 text-[#FFD700]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M5 16L3 7l5.5 4L12 4l3.5 7L21 7l-2 9H5zm2.7-2h8.6l.9-4.4L14 12l-2-4-2 4-3.2-2.4L7.7 14z" />
                </svg>
                <div className="absolute inset-0 w-8 h-8 bg-[#FFD700]/30 rounded-full blur-lg"></div>
              </div>
              <div className="text-xl font-light tracking-[0.2em] text-[#FFD700]">
                ROYAL ESSENCE
                <span className="block text-xs font-thin tracking-[0.3em] text-[#FFD700]/80">LUXURY</span>
              </div>
            </Link>
            <div className="hidden md:flex items-center space-x-12">
              <Link
                href="/"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                HOME
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                COLLECTION
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                STORY
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                CONTACT
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/wishlist">
                <Button variant="ghost" size="icon" className="text-[#FFD700] hover:bg-[#FFD700]/10">
                  <Heart className="h-5 w-5" />
                </Button>
              </Link>
              <Link href="/cart">
                <Button
                  variant="outline"
                  className="border-[#FFD700]/50 text-[#FFD700] hover:bg-[#FFD700]/10 hover:border-[#FFD700] rounded-none px-4 py-2 text-xs tracking-[0.2em]"
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  CART
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Product Detail */}
      <section className="pt-32 pb-24 bg-black">
        <div className="container mx-auto px-6">
          <Link
            href="/catalog"
            className="inline-flex items-center text-[#FFD700]/70 hover:text-[#FFD700] mb-12 text-sm tracking-widest"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            BACK TO COLLECTION
          </Link>

          <div className="grid md:grid-cols-2 gap-12 lg:gap-24">
            <div className="relative">
              <Image
                src="/placeholder.svg?height=800&width=600"
                alt={product.name}
                width={600}
                height={800}
                className="w-full object-cover"
              />
            </div>

            <div className="space-y-8">
              <div>
                <h1 className="text-4xl font-thin tracking-[0.2em] text-[#FFD700] mb-4">{product.name}</h1>
                <div className="flex items-center space-x-4 mb-4">
                  {renderStars(Math.round(averageRating))}
                  <span className="text-[#FFD700]/70">
                    ({reviews.length} review{reviews.length !== 1 ? "s" : ""})
                  </span>
                </div>
                <div className="text-3xl font-light text-[#FFD700] mb-6">€{product.price}</div>
              </div>

              <div className="inline-block border-t border-[#FFD700]/30 w-24"></div>

              <div className="space-y-6">
                <p className="text-[#FFD700]/80 leading-relaxed tracking-wider">{product.description}</p>
              </div>

              <div className="flex space-x-4 pt-8">
                <Button className="bg-[#FFD700] hover:bg-[#FFD700]/90 text-black px-12 py-6 text-sm tracking-widest flex-1">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  ADD TO CART
                </Button>
                <Button
                  variant="outline"
                  className="border-[#FFD700]/50 text-[#FFD700] hover:bg-[#FFD700]/10 hover:border-[#FFD700] px-6 py-6"
                >
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-16 bg-black border-t border-[#FFD700]/20">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-12">
              <div>
                <h2 className="text-3xl font-thin tracking-[0.2em] text-[#FFD700] mb-2">REVIEWS</h2>
                <div className="flex items-center space-x-4">
                  {renderStars(Math.round(averageRating))}
                  <span className="text-[#FFD700]/70">
                    {averageRating.toFixed(1)} out of 5 ({reviews.length} review{reviews.length !== 1 ? "s" : ""})
                  </span>
                </div>
              </div>
              <Button
                onClick={() => setShowReviewForm(!showReviewForm)}
                variant="outline"
                className="border-[#FFD700]/50 text-[#FFD700] hover:bg-[#FFD700]/10 hover:border-[#FFD700] px-6 py-3 text-sm tracking-widest"
              >
                WRITE REVIEW
              </Button>
            </div>

            {/* Review Form */}
            {showReviewForm && (
              <form onSubmit={handleSubmitReview} className="mb-12 p-6 border border-[#FFD700]/20">
                <h3 className="text-xl tracking-widest text-[#FFD700] mb-6">WRITE YOUR REVIEW</h3>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[#FFD700]/80 mb-2 text-sm tracking-widest">RATING</label>
                    {renderStars(newReview.rating, true, (rating) => setNewReview((prev) => ({ ...prev, rating })))}
                  </div>

                  <div>
                    <label className="block text-[#FFD700]/80 mb-2 text-sm tracking-widest">COMMENT</label>
                    <Textarea
                      value={newReview.comment}
                      onChange={(e) => setNewReview((prev) => ({ ...prev, comment: e.target.value }))}
                      placeholder="Share your experience with this fragrance..."
                      className="bg-transparent border-[#FFD700]/30 text-[#FFD700] placeholder-[#FFD700]/50 min-h-[120px]"
                      required
                    />
                  </div>

                  <div className="flex space-x-4">
                    <Button
                      type="submit"
                      className="bg-[#FFD700] hover:bg-[#FFD700]/90 text-black px-8 py-3 text-sm tracking-widest"
                    >
                      SUBMIT REVIEW
                    </Button>
                    <Button
                      type="button"
                      onClick={() => setShowReviewForm(false)}
                      variant="outline"
                      className="border-[#FFD700]/50 text-[#FFD700] hover:bg-[#FFD700]/10 px-8 py-3 text-sm tracking-widest"
                    >
                      CANCEL
                    </Button>
                  </div>
                </div>
              </form>
            )}

            {/* Reviews List */}
            <div className="space-y-8">
              {reviews.length === 0 ? (
                <div className="text-center py-12">
                  <Star className="h-12 w-12 text-[#FFD700]/50 mx-auto mb-4" />
                  <p className="text-[#FFD700]/70">No reviews yet. Be the first to review this fragrance!</p>
                </div>
              ) : (
                reviews.map((review) => (
                  <div key={review.id} className="border-b border-[#FFD700]/10 pb-8">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center space-x-3 mb-2">
                          <span className="text-[#FFD700] font-medium">
                            {review.user?.firstName} {review.user?.lastName}
                          </span>
                          {renderStars(review.rating)}
                        </div>
                        <p className="text-[#FFD700]/60 text-sm">
                          {review.createdAt && new Date(review.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <p className="text-[#FFD700]/80 leading-relaxed">{review.comment}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-black border-t border-[#FFD700]/20">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <Link href="/" className="text-xl font-light tracking-widest text-[#FFD700]">
                ROYAL ESSENCE
              </Link>
            </div>
            <div className="flex space-x-12 mb-6 md:mb-0">
              <Link
                href="/"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                HOME
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                COLLECTION
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                STORY
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                CONTACT
              </Link>
            </div>
            <div className="text-[#FFD700]/70 text-sm tracking-wider">© 2024 ROYAL ESSENCE LUXURY</div>
          </div>
        </div>
      </footer>
    </div>
  )
}
