"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Minus, Plus, Trash2, ShoppingCart, Heart } from "lucide-react"

interface CartItem {
  id: number
  productId: number
  quantity: number
  product?: {
    name: string
    description: string
    price: number
  }
}

export default function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [loading, setLoading] = useState(true)
  const [promoCode, setPromoCode] = useState("")

  useEffect(() => {
    loadCart()
  }, [])

  const loadCart = async () => {
    try {
      const response = await fetch("/api/cart/user/1") // Mock user ID
      if (response.ok) {
        const data = await response.json()
        setCartItems(data.items || [])
      }
    } catch (error) {
      console.error("Error loading cart:", error)
    } finally {
      setLoading(false)
    }
  }

  const updateQuantity = async (itemId: number, newQuantity: number) => {
    if (newQuantity < 1) return

    try {
      const response = await fetch(`/api/cart-items/${itemId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ quantity: newQuantity }),
      })

      if (response.ok) {
        setCartItems((items) => items.map((item) => (item.id === itemId ? { ...item, quantity: newQuantity } : item)))
      }
    } catch (error) {
      console.error("Error updating quantity:", error)
    }
  }

  const removeItem = async (itemId: number) => {
    try {
      const response = await fetch(`/api/cart-items/${itemId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setCartItems((items) => items.filter((item) => item.id !== itemId))
      }
    } catch (error) {
      console.error("Error removing item:", error)
    }
  }

  const clearCart = async () => {
    if (confirm("Are you sure you want to clear your cart?")) {
      try {
        const response = await fetch("/api/cart/user/1", {
          method: "DELETE",
        })

        if (response.ok) {
          setCartItems([])
        }
      } catch (error) {
        console.error("Error clearing cart:", error)
      }
    }
  }

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => total + (item.product?.price || 0) * item.quantity, 0)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-[#FFD700] text-xl tracking-widest">LOADING...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="border-b border-[#FFD700]/20 bg-black/90 backdrop-blur-md">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="relative">
                <svg className="w-8 h-8 text-[#FFD700]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M5 16L3 7l5.5 4L12 4l3.5 7L21 7l-2 9H5zm2.7-2h8.6l.9-4.4L14 12l-2-4-2 4-3.2-2.4L7.7 14z" />
                </svg>
                <div className="absolute inset-0 w-8 h-8 bg-[#FFD700]/30 rounded-full blur-lg"></div>
              </div>
              <div className="text-xl font-light tracking-[0.2em] text-[#FFD700]">
                ROYAL ESSENCE
                <span className="block text-xs font-thin tracking-[0.3em] text-[#FFD700]/80">LUXURY</span>
              </div>
            </Link>
            <div className="hidden md:flex items-center space-x-12">
              <Link
                href="/"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                HOME
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                COLLECTION
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                STORY
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                CONTACT
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/wishlist">
                <Button variant="ghost" size="icon" className="text-[#FFD700] hover:bg-[#FFD700]/10">
                  <Heart className="h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-6 py-12">
        <Link
          href="/catalog"
          className="inline-flex items-center text-[#FFD700]/70 hover:text-[#FFD700] mb-8 text-sm tracking-widest"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          CONTINUE SHOPPING
        </Link>

        <div className="mb-8">
          <h1 className="text-4xl font-thin tracking-[0.2em] text-[#FFD700] mb-2">SHOPPING CART</h1>
          <div className="w-24 h-px bg-[#FFD700]/50"></div>
        </div>

        {cartItems.length === 0 ? (
          <div className="text-center py-16">
            <ShoppingCart className="h-16 w-16 text-[#FFD700]/50 mx-auto mb-6" />
            <h2 className="text-2xl font-thin tracking-widest text-[#FFD700] mb-4">YOUR CART IS EMPTY</h2>
            <p className="text-[#FFD700]/70 mb-8">Discover our luxury collection of Arabian perfumes</p>
            <Button asChild className="bg-[#FFD700] hover:bg-[#FFD700]/90 text-black px-8 py-3 text-sm tracking-widest">
              <Link href="/catalog">EXPLORE COLLECTION</Link>
            </Button>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl tracking-widest text-[#FFD700]">ITEMS ({cartItems.length})</h2>
                <Button
                  variant="ghost"
                  onClick={clearCart}
                  className="text-[#FFD700]/70 hover:text-red-500 text-sm tracking-widest"
                >
                  CLEAR CART
                </Button>
              </div>

              {cartItems.map((item) => (
                <div key={item.id} className="border border-[#FFD700]/20 p-6">
                  <div className="flex gap-6">
                    <div className="w-24 h-24 bg-gray-800 rounded">
                      <Image
                        src="/placeholder.svg?height=96&width=96"
                        alt={item.product?.name || "Product"}
                        width={96}
                        height={96}
                        className="w-full h-full object-cover rounded"
                      />
                    </div>

                    <div className="flex-1">
                      <h3 className="text-lg tracking-widest text-[#FFD700] mb-2">
                        {item.product?.name || "Product Name"}
                      </h3>
                      <p className="text-[#FFD700]/70 text-sm mb-4">
                        {item.product?.description || "Product description"}
                      </p>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="border-[#FFD700]/30 text-[#FFD700] hover:bg-[#FFD700]/10 h-8 w-8"
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="text-[#FFD700] w-8 text-center">{item.quantity}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="border-[#FFD700]/30 text-[#FFD700] hover:bg-[#FFD700]/10 h-8 w-8"
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>

                        <div className="flex items-center space-x-4">
                          <span className="text-[#FFD700] font-light">
                            €{((item.product?.price || 0) * item.quantity).toFixed(2)}
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeItem(item.id)}
                            className="text-[#FFD700]/70 hover:text-red-500 h-8 w-8"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Summary */}
            <div className="space-y-6">
              <div className="border border-[#FFD700]/20 p-6">
                <h2 className="text-xl tracking-widest text-[#FFD700] mb-6">ORDER SUMMARY</h2>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between">
                    <span className="text-[#FFD700]/70">Subtotal</span>
                    <span className="text-[#FFD700]">€{getCartTotal().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#FFD700]/70">Shipping</span>
                    <span className="text-[#FFD700]">FREE</span>
                  </div>
                  <div className="border-t border-[#FFD700]/20 pt-4">
                    <div className="flex justify-between text-lg">
                      <span className="text-[#FFD700] tracking-widest">TOTAL</span>
                      <span className="text-[#FFD700] font-light">€{getCartTotal().toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Promo code"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="bg-transparent border-[#FFD700]/30 text-[#FFD700] placeholder-[#FFD700]/50"
                    />
                    <Button variant="outline" className="border-[#FFD700]/30 text-[#FFD700] hover:bg-[#FFD700]/10 px-6">
                      APPLY
                    </Button>
                  </div>

                  <Button className="w-full bg-[#FFD700] hover:bg-[#FFD700]/90 text-black py-6 text-sm tracking-widest">
                    PROCEED TO CHECKOUT
                  </Button>
                </div>
              </div>

              <div className="text-center text-[#FFD700]/70 text-sm">
                <p>Secure checkout with SSL encryption</p>
                <p className="mt-2">Free shipping on orders over €100</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
