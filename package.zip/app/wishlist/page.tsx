"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Heart } from "lucide-react"

interface WishlistItem {
  id: number
  productId: number
  product?: {
    name: string
    description: string
    price: number
  }
}

export default function WishlistPage() {
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadWishlist()
  }, [])

  const loadWishlist = async () => {
    try {
      const response = await fetch("/api/wishlist/user/1") // Mock user ID
      if (response.ok) {
        const data = await response.json()
        setWishlistItems(data)
      }
    } catch (error) {
      console.error("Error loading wishlist:", error)
    } finally {
      setLoading(false)
    }
  }

  const removeFromWishlist = async (productId: number) => {
    try {
      const response = await fetch(`/api/wishlist/${productId}`, {
        method: "DELETE",
      })
      if (response.ok) {
        setWishlistItems((items) => items.filter((item) => item.productId !== productId))
      }
    } catch (error) {
      console.error("Error removing from wishlist:", error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-[#FFD700] text-xl tracking-widest">LOADING...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="border-b border-[#FFD700]/20 bg-black/90 backdrop-blur-md">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="relative">
                <svg className="w-8 h-8 text-[#FFD700]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M5 16L3 7l5.5 4L12 4l3.5 7L21 7l-2 9H5zm2.7-2h8.6l.9-4.4L14 12l-2-4-2 4-3.2-2.4L7.7 14z" />
                </svg>
                <div className="absolute inset-0 w-8 h-8 bg-[#FFD700]/30 rounded-full blur-lg"></div>
              </div>
              <div className="text-xl font-light tracking-[0.2em] text-[#FFD700]">
                ROYAL ESSENCE
                <span className="block text-xs font-thin tracking-[0.3em] text-[#FFD700]/80">LUXURY</span>
              </div>
            </Link>
            <div className="hidden md:flex items-center space-x-12">
              <Link
                href="/"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                HOME
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                COLLECTION
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                STORY
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                CONTACT
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-6 py-12">
        <Link
          href="/catalog"
          className="inline-flex items-center text-[#FFD700]/70 hover:text-[#FFD700] mb-8 text-sm tracking-widest"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          CONTINUE SHOPPING
        </Link>

        <div className="mb-8">
          <h1 className="text-4xl font-thin tracking-[0.2em] text-[#FFD700] mb-2">WISHLIST</h1>
          <div className="w-24 h-px bg-[#FFD700]/50"></div>
        </div>

        {wishlistItems.length === 0 ? (
          <div className="text-center py-16">
            <Heart className="h-16 w-16 text-[#FFD700]/50 mx-auto mb-6" />
            <h2 className="text-2xl font-thin tracking-widest text-[#FFD700] mb-4">YOUR WISHLIST IS EMPTY</h2>
            <p className="text-[#FFD700]/70 mb-8">Save your favorite perfumes for later</p>
            <Button asChild className="bg-[#FFD700] hover:bg-[#FFD700]/90 text-black px-8 py-3 text-sm tracking-widest">
              <Link href="/catalog">EXPLORE COLLECTION</Link>
            </Button>
          </div>
        ) : (
          <div>
            <div className="mb-6">
              <p className="text-[#FFD700]/70 tracking-wider">
                {wishlistItems.length} item{wishlistItems.length !== 1 ? "s" : ""} in your wishlist
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {wishlistItems.map((item) => (
                <div key={item.id} className="group relative">
                  <div className="relative overflow-hidden">
                    <Image
                      src="/placeholder.svg?height=400&width=300"
                      alt={item.product?.name || "Product"}
                      width={300}
                      height={400}
                      className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeFromWishlist(item.productId)}
                      className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm hover:bg-black/70 text-red-500 rounded-full"
                    >
                      <Heart className="h-4 w-4 fill-current" />
                    </Button>

                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                      <Link href={`/product/${item.productId}`}>
                        <span className="text-[#FFD700] border border-[#FFD700]/40 bg-black/30 backdrop-blur-sm px-8 py-3 text-sm tracking-widest block text-center hover:bg-[#FFD700]/10 transition-colors">
                          VIEW DETAILS
                        </span>
                      </Link>
                    </div>
                  </div>
                  <div className="mt-6 text-center">
                    <h3 className="text-xl tracking-widest text-[#FFD700] mb-2">
                      {item.product?.name || "Product Name"}
                    </h3>
                    <p className="text-[#FFD700]/70 text-sm mb-2">
                      {item.product?.description || "Product description"}
                    </p>
                    <div className="text-lg font-light text-[#FFD700]">€{item.product?.price || 0}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
