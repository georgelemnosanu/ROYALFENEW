import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function StoryPage() {
  const milestones = [
    {
      year: "1998",
      title: "ORIGINS",
      description: "Royal Essence begins its journey in the heart of Arabia.",
    },
    {
      year: "2005",
      title: "DISCOVERY",
      description: "Our master perfumer discovers a rare oud source in Cambodia.",
    },
    {
      year: "2012",
      title: "EXPANSION",
      description: "The brand expands globally, bringing Arabian luxury worldwide.",
    },
    {
      year: "2018",
      title: "INNOVATION",
      description: "Introduction of our exclusive extraction method for purer essences.",
    },
    {
      year: "2023",
      title: "LEGACY",
      description: "Launch of our most prestigious collection, celebrating 25 years of excellence.",
    },
  ]

  const craftsmen = [
    {
      name: "MASTER PERFUMER",
      image: "/placeholder.svg?height=600&width=500",
      description: "With over 30 years of experience, our Master Perfumer selects only the finest ingredients.",
    },
    {
      name: "ARTISAN BLENDER",
      image: "/placeholder.svg?height=600&width=500",
      description: "Each fragrance is meticulously blended by hand, following ancient Arabian traditions.",
    },
    {
      name: "BOTTLE DESIGNER",
      image: "/placeholder.svg?height=600&width=500",
      description: "Our bottles are handcrafted by master glassblowers, adorned with 24k gold accents.",
    },
  ]

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-black/90 backdrop-blur-md border-b border-[#FFD700]/20">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="relative">
                <svg className="w-8 h-8 text-[#FFD700]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M5 16L3 7l5.5 4L12 4l3.5 7L21 7l-2 9H5zm2.7-2h8.6l.9-4.4L14 12l-2-4-2 4-3.2-2.4L7.7 14z" />
                </svg>
                <div className="absolute inset-0 w-8 h-8 bg-[#FFD700]/30 rounded-full blur-lg"></div>
              </div>
              <div className="text-xl font-light tracking-[0.2em] text-[#FFD700]">
                ROYAL ESSENCE
                <span className="block text-xs font-thin tracking-[0.3em] text-[#FFD700]/80">LUXURY</span>
              </div>
            </Link>
            <div className="hidden md:flex items-center space-x-12">
              <Link
                href="/"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                HOME
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                COLLECTION
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
              <Link
                href="/story"
                className="text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                STORY
                <div className="absolute -bottom-1 left-0 w-full h-px bg-[#FFD700]"></div>
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-all duration-300 text-sm tracking-[0.2em] relative group"
              >
                CONTACT
                <div className="absolute -bottom-1 left-0 w-0 h-px bg-[#FFD700] transition-all duration-300 group-hover:w-full"></div>
              </Link>
            </div>
            <Link href="/contact">
              <Button
                variant="outline"
                className="border-[#FFD700]/50 text-[#FFD700] hover:bg-[#FFD700]/10 hover:border-[#FFD700] rounded-none px-6 py-2 text-xs tracking-[0.2em]"
              >
                CONTACT
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Desert luxury"
            fill
            className="object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-black/60"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl md:text-6xl font-thin tracking-[0.2em] text-[#FFD700] mb-8">OUR STORY</h1>
            <div className="flex justify-center mb-8">
              <div className="w-24 h-px bg-gradient-to-r from-transparent via-[#FFD700] to-transparent"></div>
            </div>
            <p className="text-xl md:text-2xl font-light tracking-wider text-[#FFD700]/90 mb-12 leading-relaxed">
              A LEGACY OF ARABIAN LUXURY PERFUMERY
            </p>
            <p className="text-[#FFD700]/80 leading-relaxed tracking-wider max-w-3xl mx-auto">
              For over two decades, Royal Essence has been crafting the finest Arabian perfumes, blending ancient
              traditions with modern sophistication. Our journey began in the heart of the Arabian desert, where the art
              of perfumery has been practiced for centuries.
            </p>
          </div>
        </div>
      </section>

      {/* Heritage Section */}
      <section className="py-20 bg-black relative">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#FFD700]/30 to-transparent"></div>
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-thin tracking-[0.2em] text-[#FFD700] mb-8">OUR HERITAGE</h2>
              <div className="w-16 h-px bg-[#FFD700]/50 mb-8"></div>
              <div className="space-y-6 text-[#FFD700]/80 leading-relaxed tracking-wider">
                <p>
                  Royal Essence was founded on the principles of authenticity, craftsmanship, and luxury. Our founder,
                  inspired by the rich olfactory traditions of Arabia, set out to create fragrances that would capture
                  the essence of the desert's mystique.
                </p>
                <p>
                  Each Royal Essence creation is a testament to our commitment to excellence. We source the rarest
                  ingredients from around the world – from Cambodian oud and Bulgarian rose to Omani frankincense and
                  Indian saffron.
                </p>
                <p>
                  Our perfumes are more than just fragrances; they are liquid art, telling stories of ancient trade
                  routes, royal palaces, and desert oases. They embody the spirit of Arabian hospitality and the
                  opulence of its heritage.
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="relative z-10 border-4 border-[#FFD700]/20">
                <Image
                  src="/placeholder.svg?height=800&width=600"
                  alt="Heritage"
                  width={600}
                  height={800}
                  className="w-full"
                />
              </div>
              <div className="absolute -top-6 -right-6 w-full h-full border-4 border-[#FFD700]/30 z-0"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 bg-black relative">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#FFD700]/30 to-transparent"></div>
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-thin tracking-[0.2em] text-[#FFD700] mb-6">OUR JOURNEY</h2>
            <div className="flex justify-center mb-8">
              <div className="w-24 h-px bg-gradient-to-r from-transparent via-[#FFD700]/50 to-transparent"></div>
            </div>
          </div>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-px bg-[#FFD700]/30"></div>

            <div className="space-y-24">
              {milestones.map((milestone, index) => (
                <div key={index} className={`relative flex ${index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}>
                  <div className="flex-1 md:pr-12 md:pl-0 pl-12">
                    <div className={`text-right ${index % 2 !== 0 && "md:text-left"}`}>
                      <div className="text-4xl font-light text-[#FFD700] mb-4">{milestone.year}</div>
                      <h3 className="text-xl tracking-widest text-[#FFD700]/90 mb-3">{milestone.title}</h3>
                      <p className="text-[#FFD700]/70">{milestone.description}</p>
                    </div>
                  </div>

                  {/* Center dot */}
                  <div className="absolute left-0 md:left-1/2 top-0 transform md:-translate-x-1/2 flex items-center justify-center">
                    <div className="w-6 h-6 rounded-full bg-black border-2 border-[#FFD700] z-10"></div>
                    <div className="absolute w-10 h-10 rounded-full bg-[#FFD700]/20 animate-pulse"></div>
                  </div>

                  <div className="flex-1 md:pl-12 hidden md:block"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Craftsmanship Section */}
      <section className="py-20 bg-black relative">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#FFD700]/30 to-transparent"></div>
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-thin tracking-[0.2em] text-[#FFD700] mb-6">OUR CRAFTSMEN</h2>
            <div className="flex justify-center mb-8">
              <div className="w-24 h-px bg-gradient-to-r from-transparent via-[#FFD700]/50 to-transparent"></div>
            </div>
            <p className="text-[#FFD700]/80 max-w-3xl mx-auto">
              Behind every Royal Essence creation stands a team of dedicated artisans who have mastered their craft
              through years of experience and devotion.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            {craftsmen.map((craftsman, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-8 overflow-hidden">
                  <Image
                    src={craftsman.image || "/placeholder.svg"}
                    alt={craftsman.name}
                    width={500}
                    height={600}
                    className="w-full transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-60"></div>
                </div>
                <h3 className="text-xl tracking-widest text-[#FFD700] mb-4">{craftsman.name}</h3>
                <p className="text-[#FFD700]/70">{craftsman.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-black relative">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#FFD700]/30 to-transparent"></div>
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-thin tracking-[0.2em] text-[#FFD700] mb-8">EXPERIENCE THE LUXURY</h2>
            <p className="text-[#FFD700]/80 mb-12">
              Discover our exclusive collection of Arabian perfumes and embark on a sensory journey through the mystique
              and opulence of the desert.
            </p>
            <Button
              asChild
              className="bg-transparent hover:bg-[#FFD700]/20 text-[#FFD700] border-2 border-[#FFD700] rounded-none px-12 py-6 text-sm tracking-[0.3em] transition-all duration-500 hover:shadow-lg hover:shadow-[#FFD700]/25"
            >
              <Link href="/catalog">EXPLORE COLLECTION</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-black border-t border-[#FFD700]/20">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <Link href="/" className="text-xl font-light tracking-widest text-[#FFD700]">
                ROYAL ESSENCE
              </Link>
            </div>
            <div className="flex space-x-12 mb-6 md:mb-0">
              <Link
                href="/"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                HOME
              </Link>
              <Link
                href="/catalog"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                COLLECTION
              </Link>
              <Link href="/story" className="text-[#FFD700] transition-colors text-sm tracking-widest">
                STORY
              </Link>
              <Link
                href="/contact"
                className="text-[#FFD700]/80 hover:text-[#FFD700] transition-colors text-sm tracking-widest"
              >
                CONTACT
              </Link>
            </div>
            <div className="text-[#FFD700]/70 text-sm tracking-wider">© 2024 ROYAL ESSENCE LUXURY</div>
          </div>
        </div>
      </footer>
    </div>
  )
}
