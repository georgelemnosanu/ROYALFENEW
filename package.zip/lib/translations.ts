"use client"

export type Language = "ro" | "en"

export const translations = {
  ro: {
    // Navigation
    home: "ACASĂ",
    collection: "COLECȚIE",
    story: "POVESTE",
    contact: "CONTACT",
    cart: "COȘ",
    wishlist: "FAVORITE",
    admin: "ADMIN",

    // Common
    loading: "Se încarcă...",
    price: "Preț",
    add_to_cart: "ADAUGĂ ÎN COȘ",
    add_to_wishlist: "ADAUGĂ LA FAVORITE",
    view_details: "VEZI DETALII",
    save: "SALVEAZĂ",
    cancel: "ANULEAZĂ",
    delete: "ȘTERGE",
    edit: "EDITEAZĂ",
    create: "CREEAZĂ",

    // Product
    products: "PRODUSE",
    product_name: "Nume Produs",
    product_description: "Descriere",
    product_price: "Preț",
    product_category: "Categorie",
    featured_products: "PRODUSE RECOMANDATE",

    // Hero Section
    luxury_arabian_perfumes: "PARFUMURI ARABEȘTI DE LUX",
    crafted_in_desert: "Create în Inima Deșertului",
    discover_collection: "DESCOPERĂ COLECȚIA",
    explore_story: "EXPLOREAZĂ POVESTEA",
    signature_collection: "COLECȚIA SEMNĂTURĂ",

    // Admin
    admin_dashboard: "PANOU ADMINISTRARE",
    products_management: "GESTIONARE PRODUSE",
    categories_management: "GESTIONARE CATEGORII",
    users_management: "GESTIONARE UTILIZATORI",

    // Language
    language: "Limbă",
    romanian: "Română",
    english: "English",
  },

  en: {
    // Navigation
    home: "HOME",
    collection: "COLLECTION",
    story: "STORY",
    contact: "CONTACT",
    cart: "CART",
    wishlist: "WISHLIST",
    admin: "ADMIN",

    // Common
    loading: "Loading...",
    price: "Price",
    add_to_cart: "ADD TO CART",
    add_to_wishlist: "ADD TO WISHLIST",
    view_details: "VIEW DETAILS",
    save: "SAVE",
    cancel: "CANCEL",
    delete: "DELETE",
    edit: "EDIT",
    create: "CREATE",

    // Product
    products: "PRODUCTS",
    product_name: "Product Name",
    product_description: "Description",
    product_price: "Price",
    product_category: "Category",
    featured_products: "FEATURED PRODUCTS",

    // Hero Section
    luxury_arabian_perfumes: "LUXURY ARABIAN PERFUMES",
    crafted_in_desert: "Crafted in the Heart of the Desert",
    discover_collection: "DISCOVER COLLECTION",
    explore_story: "EXPLORE STORY",
    signature_collection: "SIGNATURE COLLECTION",

    // Admin
    admin_dashboard: "ADMIN DASHBOARD",
    products_management: "PRODUCTS MANAGEMENT",
    categories_management: "CATEGORIES MANAGEMENT",
    users_management: "USERS MANAGEMENT",

    // Language
    language: "Language",
    romanian: "Română",
    english: "English",
  },
} as const

// Funcție pentru a obține limba din localStorage
function getCurrentLanguage(): Language {
  if (typeof window !== "undefined") {
    const saved = localStorage.getItem("language")
    return (saved as Language) || "en"
  }
  return "en"
}

// Funcție pentru a salva limba în localStorage
function setCurrentLanguage(lang: Language) {
  if (typeof window !== "undefined") {
    localStorage.setItem("language", lang)
    // Trigger a custom event to notify other components
    window.dispatchEvent(new CustomEvent("languageChange", { detail: lang }))
  }
}

// Funcție simplă pentru a obține traducerile
export function getTranslations(lang: Language = "en") {
  return translations[lang]
}

// Hook simplu pentru limba curentă
export function useSimpleLanguage() {
  const [currentLang, setCurrentLang] = React.useState<Language>("en")

  React.useEffect(() => {
    // Set initial language from localStorage
    setCurrentLang(getCurrentLanguage())

    // Listen for language changes
    const handleLanguageChange = (event: CustomEvent<Language>) => {
      setCurrentLang(event.detail)
    }

    window.addEventListener("languageChange", handleLanguageChange as EventListener)
    return () => {
      window.removeEventListener("languageChange", handleLanguageChange as EventListener)
    }
  }, [])

  const changeLanguage = (lang: Language) => {
    setCurrentLanguage(lang)
    setCurrentLang(lang)
  }

  const t = getTranslations(currentLang)

  return { t, currentLang, changeLanguage }
}

// Import React pentru useState și useEffect
import React from "react"
